0.1 (2012-03-03)
================

- Initial release
- Basic support for packages

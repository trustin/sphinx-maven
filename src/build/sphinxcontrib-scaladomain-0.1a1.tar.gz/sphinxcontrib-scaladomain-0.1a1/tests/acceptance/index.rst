.. shinxcontrib-scaladomain-acceptancetest documentation master file, created by
   sphinx-quickstart on Mon Mar  5 13:50:55 2012.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to shinxcontrib-scaladomain-acceptancetest's documentation!
===================================================================

.. scl:package:: scala

Scala Package
-------------

.. scl:package:: scala.actors
   :deprecated:

Scala Actors Packages
---------------------

.. scl:package:: scala.collection
   :synopsis: Collections

Scala Collections Packages
--------------------------

.. scl:package:: scala.collection.generic

Scala Generic Collections Package
---------------------------------

.. scl:package:: scala.collection.immutable

Scala Immutable Collections Package
-----------------------------------

.. scl:package:: scala.collection.interfaces

Scala Collection Interfaces Package
-----------------------------------

.. scl:package:: scala.collection.mutable

Scala Mutable Collections Package
---------------------------------

.. scl:package:: scala.collection.parallel

Scala Parallel Collections Package
----------------------------------

.. scl:package:: scala.collection.parallel.immutable

Scala Parallel Immutable Collections Package
--------------------------------------------

.. scl:package:: scala.collection.parallel.mutable

Scala Parallel Mutable Collections Package
------------------------------------------

.. scl:package:: scala.collection.script

Scala Collection Scripts Package
--------------------------------

References
==========

- :scl:pkg:`scala`
- :scl:pkg:`scala.actors`
- :scl:pkg:`scala.collection`
- :scl:pkg:`scala.collection.generic`
- :scl:pkg:`scala.collection.immutable`
- :scl:pkg:`scala.collection.interfaces`
- :scl:pkg:`scala.collection.mutable`
- :scl:pkg:`scala.collection.parallel`
- :scl:pkg:`scala.collection.parallel.immutable`
- :scl:pkg:`scala.collection.parallel.mutable`
- :scl:pkg:`scala.collection.script`

Indices and tables
==================

* :ref:`genindex`
* :ref:`search`

